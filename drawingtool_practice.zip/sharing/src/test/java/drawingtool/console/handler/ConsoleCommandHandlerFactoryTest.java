package drawingtool.console.handler;

import dmoen.drawingtool.console.ConsoleCommand;
import dmoen.drawingtool.console.handler.ConsoleCommandArgumentHandlerFactory;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertNotNull;

public class ConsoleCommandHandlerFactoryTest
{
  private ConsoleCommandArgumentHandlerFactory consoleCommandHandlerFactory;

  @Before
  public void init()
  {
    consoleCommandHandlerFactory = new ConsoleCommandArgumentHandlerFactory();
  }

  @Test
  public void testConsoleCommandHandlers()
  {
    for (ConsoleCommand command : ConsoleCommand.values()) {
      assertNotNull(consoleCommandHandlerFactory.handlerFor(command));
    }
  }
}
