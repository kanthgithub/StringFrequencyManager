package dmoen.drawingtool;


public interface Shape
{  
  void addTo(Canvas canvas);
}
