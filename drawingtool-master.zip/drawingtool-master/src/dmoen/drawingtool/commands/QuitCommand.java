package dmoen.drawingtool.commands;

import dmoen.drawingtool.DrawingTool;

public class QuitCommand implements Command
{

  @Override
  public void executeOn(DrawingTool drawingTool)
  {
    // TODO noop
  }
}
